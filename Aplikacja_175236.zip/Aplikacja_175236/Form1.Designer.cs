﻿namespace Aplikacja_175236
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dodajDoKolejkiButton = new Button();
            usunZKolejkiButton = new Button();
            zaproponujUtworButton = new Button();
            Baza = new ListBox();
            Kolejka = new ListBox();
            proponowanyUtworLabel = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // dodajDoKolejkiButton
            // 
            dodajDoKolejkiButton.Font = new Font("Snap ITC", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dodajDoKolejkiButton.Location = new Point(1009, 84);
            dodajDoKolejkiButton.Name = "dodajDoKolejkiButton";
            dodajDoKolejkiButton.Size = new Size(203, 115);
            dodajDoKolejkiButton.TabIndex = 0;
            dodajDoKolejkiButton.Text = "Dodaj utwór";
            dodajDoKolejkiButton.UseVisualStyleBackColor = true;
            dodajDoKolejkiButton.Click += dodajDoKolejkiButton_Click;
            // 
            // usunZKolejkiButton
            // 
            usunZKolejkiButton.BackColor = Color.Transparent;
            usunZKolejkiButton.Font = new Font("Snap ITC", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            usunZKolejkiButton.Location = new Point(1009, 248);
            usunZKolejkiButton.Name = "usunZKolejkiButton";
            usunZKolejkiButton.Size = new Size(203, 115);
            usunZKolejkiButton.TabIndex = 1;
            usunZKolejkiButton.Text = "Usuń utwór";
            usunZKolejkiButton.UseVisualStyleBackColor = false;
            usunZKolejkiButton.Click += usunZKolejkiButton_Click;
            // 
            // zaproponujUtworButton
            // 
            zaproponujUtworButton.Font = new Font("Snap ITC", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            zaproponujUtworButton.Location = new Point(1009, 410);
            zaproponujUtworButton.Name = "zaproponujUtworButton";
            zaproponujUtworButton.Size = new Size(203, 115);
            zaproponujUtworButton.TabIndex = 2;
            zaproponujUtworButton.Text = "Zaproponuj Utwór";
            zaproponujUtworButton.UseVisualStyleBackColor = true;
            zaproponujUtworButton.Click += zaproponujUtworButton_Click;
            // 
            // Baza
            // 
            Baza.FormattingEnabled = true;
            Baza.ItemHeight = 25;
            Baza.Location = new Point(37, 84);
            Baza.Name = "Baza";
            Baza.Size = new Size(411, 579);
            Baza.TabIndex = 3;
            // 
            // Kolejka
            // 
            Kolejka.FormattingEnabled = true;
            Kolejka.ItemHeight = 25;
            Kolejka.Location = new Point(529, 84);
            Kolejka.Name = "Kolejka";
            Kolejka.Size = new Size(411, 579);
            Kolejka.TabIndex = 4;
            // 
            // proponowanyUtworLabel
            // 
            proponowanyUtworLabel.AutoSize = true;
            proponowanyUtworLabel.BackColor = Color.White;
            proponowanyUtworLabel.Location = new Point(37, 706);
            proponowanyUtworLabel.Name = "proponowanyUtworLabel";
            proponowanyUtworLabel.Size = new Size(388, 25);
            proponowanyUtworLabel.TabIndex = 5;
            proponowanyUtworLabel.Text = "Brak dostępnych utworów do zaproponowania.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Cursor = Cursors.Cross;
            label1.Font = new Font("Showcard Gothic", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(95, 24);
            label1.Name = "label1";
            label1.Size = new Size(292, 40);
            label1.TabIndex = 6;
            label1.Text = "Baza utworów";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Showcard Gothic", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(526, 24);
            label2.Name = "label2";
            label2.Size = new Size(414, 40);
            label2.TabIndex = 7;
            label2.Text = "Kolejka odtwarzania";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SandyBrown;
            ClientSize = new Size(1262, 793);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(proponowanyUtworLabel);
            Controls.Add(Kolejka);
            Controls.Add(Baza);
            Controls.Add(zaproponujUtworButton);
            Controls.Add(usunZKolejkiButton);
            Controls.Add(dodajDoKolejkiButton);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button dodajDoKolejkiButton;
        private Button usunZKolejkiButton;
        private Button zaproponujUtworButton;
        private Label proponowanyUtworLabel;
        private Label label1;
        private Label label2;
        private ListBox Baza;
        private ListBox Kolejka;
    }
}
