﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplikacja_175236
{
    internal class Utwor
    {
        public string Tytul { get; set; }
        public string Wykonawca { get; set; }
        public string Gatunek { get; set; }

        public Utwor(string tytul, string wykonawca, string gatunek)
        {
            Tytul = tytul;
            Wykonawca = wykonawca;
            Gatunek = gatunek;
        }

        public override string ToString()
        {
            return $"{Tytul} - {Wykonawca} ({Gatunek})";
        }
    }
}
